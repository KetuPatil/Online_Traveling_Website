A simple project made using JSP Servlets and JDBC connected with Database using MYSQL Workbench and HTML, CSS used to develop the basic frontend of the site.
The user can use this website to select a perfect place for their next trip where he/she can select from the numerous options recommended in the website.
